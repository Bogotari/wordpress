<?php

namespace Simply_Static;

class Pause_Exception extends \Exception {}
