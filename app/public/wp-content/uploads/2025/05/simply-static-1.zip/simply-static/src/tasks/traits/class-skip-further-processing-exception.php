<?php

namespace Simply_Static;

class Skip_Further_Processing_Exception extends \Exception {}